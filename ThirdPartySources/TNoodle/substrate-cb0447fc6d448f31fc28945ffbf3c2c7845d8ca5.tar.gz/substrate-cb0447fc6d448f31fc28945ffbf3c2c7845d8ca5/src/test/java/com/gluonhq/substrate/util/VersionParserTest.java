/*
 * Copyright (c) 2019, Gluon
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL GLUON BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.gluonhq.substrate.util;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class VersionParserTest {

    @Test
    public void returnsSameInputWhenInputIsEmpty() {
        String input = "";
        VersionParser versionParser = new VersionParser();
        Version version = versionParser.parseVersion(input);
        assertNull(version);
    }

    @Test
    public void returnsSameInputWhenNoVersionPresent() {
        String input = "ld";
        VersionParser versionParser = new VersionParser();
        Version version = versionParser.parseVersion(input);
        assertNull(version);
    }

    @Test
    public void parsesVersionFromVersionWithoutMinorNumber() {
        String input = "ld 2";
        VersionParser versionParser = new VersionParser();
        Version version = versionParser.parseVersion(input);
        assertEquals(2, version.getMajor());
    }

    @Test
    public void parsesVersionFromVersionWithoutPatchNumber() {
        String input = "ld 2.26";
        VersionParser versionParser = new VersionParser();
        Version version = versionParser.parseVersion(input);
        assertEquals(2, version.getMajor());
        assertEquals(26, version.getMinor());
    }

    @Test
    public void parsesVersionFromFullVersionNumber() {
        String input = "ld 2.26.1";
        VersionParser versionParser = new VersionParser();
        Version version = versionParser.parseVersion(input);
        assertEquals(2, version.getMajor());
        assertEquals(26, version.getMinor());
        assertEquals(1, version.getPatch());
    }

    @Test
    public void parsesBaseVersionFromVersionWithExtraInfo() {
        String input = "GNU ld version 2.27-41.base.el7";
        VersionParser versionParser = new VersionParser();
        Version version = versionParser.parseVersion(input);
        assertEquals(2, version.getMajor());
        assertEquals(27, version.getMinor());
    }
}
