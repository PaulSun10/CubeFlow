/*
 * Copyright (c) 2022, Oracle and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.  Oracle designates this
 * particular file as subject to the "Classpath" exception as provided
 * by Oracle in the LICENSE file that accompanied this code.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Oracle, 500 Oracle Parkway, Redwood Shores, CA 94065 USA
 * or visit www.oracle.com if you need additional information or have any
 * questions.
 */
package org.graalvm.compiler.core.test;

import org.graalvm.compiler.debug.GraalError;
import org.graalvm.compiler.nodes.StructuredGraph;
import org.graalvm.compiler.nodes.spi.CoreProviders;
import org.graalvm.compiler.phases.SingleRunSubphase;
import org.junit.Test;

/**
 * Tests that {@link SingleRunSubphase} instances fail as expected when we try to run them more than
 * once.
 */
public class SingleRunSubphaseTest extends GraalCompilerTest {

    public static int testSnippet(int a, int b) {
        return a + b;
    }

    static class EmptyPhase extends SingleRunSubphase<CoreProviders> {

        int mutableCounter = 0;

        @Override
        protected void run(StructuredGraph graph, CoreProviders context) {
            mutableCounter++;
        }
    }

    @Test
    public void testSingleRun() {
        StructuredGraph graph = parseForCompile(getResolvedJavaMethod("testSnippet"));
        EmptyPhase phase = new EmptyPhase();
        phase.apply(graph, getProviders());
    }

    @Test(expected = GraalError.class)
    public void testMultipleRuns() {
        StructuredGraph graph = parseForCompile(getResolvedJavaMethod("testSnippet"));
        EmptyPhase phase = new EmptyPhase();
        phase.apply(graph, getProviders());
        // this second call should throw
        phase.apply(graph, getProviders());
    }
}
